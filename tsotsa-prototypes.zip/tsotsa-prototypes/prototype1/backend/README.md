# ontology-server

# CONFIG EXAMPLE
- GRAPHDB_BASE_URL=http://localhost:7200
- GRAPHDB_REPOSITORY=food
- GRAPHDB_USERNAME=test
- GRAPHDB_PASSWORD=test
- GRAPHDB_PREFIX=food
- ONTOLOGY_URI=http://localhost/ontologies/2021/food#
