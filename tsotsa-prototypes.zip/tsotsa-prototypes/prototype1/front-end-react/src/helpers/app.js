/** @format */

import { Namespace } from 'rdflib';

export const appNS = Namespace();
