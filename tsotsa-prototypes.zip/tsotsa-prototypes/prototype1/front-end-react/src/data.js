/** @format */

export default [
  {
    food: 'Gombo',
    classe: 'aliment',
    description: 'lorem ipsum ipsum ipsum',
    substance: ['Glucose', 'Phosphate', 'VitamineA'],
  },
  {
    food: 'Sucre',
    classe: 'aliment',
    description: 'lorem ipsum ipsum ipsum',
    substance: ['Glucose', 'Phosphate', 'VitamineA'],
  },
  {
    food: 'Carotte',
    classe: 'Legumes Fruit',
    description: 'lorem ipsum ipsum ipsum',
    substance: ['Vitamne D', 'Soduim', 'Lipides'],
  },
  {
    food: 'CousCousSauceGombo',
    classe: 'Repas',
    description: 'Est un Ensemble de Sauce Gombo ',
    substance: ['Vitamne D', 'Soduim', 'Lipides'],
  },
];
